public abstract class AbstractStack implements Stack {
    private int size;

    public void push(Object element) {
        doPush(element);
        size++;
    }

    protected abstract void doPush(Object element);

    public Object pop() {
        if (isEmpty()) {
            return null;
        }
        Object element = doPop();
        size--;
        return element;
    }

    protected abstract Object doPop();

    public Object peek() {
        if (isEmpty()) {
            return null;
        }
        Object element = doPop();
        doPush(element);
        return element;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
