public class LinkedStack extends AbstractStack {
    private Node head;

    private static class Node {
        private Object element;
        private Node next;

        public Node(Object element, Node next) {
            this.element = element;
            this.next = next;
        }
    }

    public void doPush(Object element) {
        head = new Node(element, head);
    }

    public Object doPop() {
        Object element = head.element;
        head = head.next;
        return element;
    }
}
