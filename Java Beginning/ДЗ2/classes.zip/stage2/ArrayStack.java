public class ArrayStack extends AbstractStack {
    private Object[] elements;

    public ArrayStack() {
        elements = new Object[4];
    }

    protected void doPush(Object element) {
        ensureCapacity(size() + 1);
        elements[size()] = element;
    }

    private void ensureCapacity(int capacity) {
        if (elements.length >= capacity) {
            return;
        }
        int newCapacity = Math.max(elements.length * 2, capacity);
        Object[] newElements = new Object[newCapacity];

        for (int i = 0; i < size(); i++) {
            newElements[i] = elements[i];
        }
        elements = newElements;
    }

    protected Object doPop() {
        Object element = elements[size() - 1];
        elements[size() - 1] = null;
        return element;
    }
}
