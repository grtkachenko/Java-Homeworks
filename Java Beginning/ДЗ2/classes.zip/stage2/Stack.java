public interface Stack {
    void push(Object element);

    Object pop();

    Object peek();

    int size();

    boolean isEmpty();
}
