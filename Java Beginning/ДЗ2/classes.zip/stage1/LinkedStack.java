public class LinkedStack {
    private int size;
    private Node head;

    private static class Node {
        private Object element;
        private Node next;

        public Node(Object element, Node next) {
            this.element = element;
            this.next = next;
        }
    }

    public void push(Object element) {
        head = new Node(element, head);
        size++;
    }

    public Object pop() {
        if (isEmpty()) {
            return null;
        }

        Object element = head.element;
        head = head.next;
        size--;
        return element;
    }

    public Object peek() {
        if (isEmpty()) {
            return null;
        }
        return head.element;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
