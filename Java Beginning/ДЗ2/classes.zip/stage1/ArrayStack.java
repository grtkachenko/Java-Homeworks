public class ArrayStack {
    private int size;
    private Object[] elements;

    public ArrayStack() {
        elements = new Object[10];
    }

    public void push(Object element) {
        ensureCapacity(size + 1);
        elements[size++] = element;
    }

    private void ensureCapacity(int capacity) {
        if (elements.length >= capacity) {
            return;
        }
        int newCapacity = Math.max(elements.length * 2, capacity);
        Object[] newElements = new Object[newCapacity];

        for (int i = 0; i < size; i++) {
            newElements[i] = elements[i];
        }
        elements = newElements;
    }

    public Object pop() {
        if (isEmpty()) {
            return null;
        }
        Object element = elements[size - 1];
        elements[size - 1] = null;
        size--;
        return element;
    }

    public Object peek() {
        if (isEmpty()) {
            return null;
        }
        return elements[size - 1];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
