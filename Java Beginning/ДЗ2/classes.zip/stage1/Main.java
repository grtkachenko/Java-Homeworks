public class Main {
    private static void fillStack(ArrayStack stack, int size) {
        for (int i = 0; i < size; i++) {
            stack.push(new Integer(i));
        }
        System.out.println("Stack size: " + stack.size());
    }

    private static void dumpStack(ArrayStack stack) {
        while (!stack.isEmpty()) {
            System.out.println(stack.pop());
        }
    }

    private static void fillStack(LinkedStack stack, int size) {
        for (int i = 0; i < size; i++) {
            stack.push(new Integer(i));
        }
        System.out.println("Stack size: " + stack.size());
    }

    private static void dumpStack(LinkedStack stack) {
        while (!stack.isEmpty()) {
            System.out.println(stack.pop());
        }
    }

    public static void main(String[] args) {
        ArrayStack arrayStack = new ArrayStack();
        fillStack(arrayStack, 10);
        dumpStack(arrayStack);

        LinkedStack linkedStack = new LinkedStack();
        fillStack(linkedStack, 10);
        dumpStack(linkedStack);
    }
}